# Greetings Page

Αυτό το πακέτο περιέχει μια απλή ιστοσελίδα.

## Περιεχόμενα
- index.html → η σελίδα
- world-map.jpeg → η εικόνα με τον χάρτη

## Οδηγίες
1. Ανεβάστε αυτά τα αρχεία σε ένα GitHub repository.
2. Από τις ρυθμίσεις, ενεργοποιήστε το **GitHub Pages** και επιλέξτε branch `main` + folder `/ (root)`.
3. Η σελίδα σας θα είναι διαθέσιμη στη διεύθυνση:
   `https://<το-username-σας>.github.io/<το-repo-σας>/`
